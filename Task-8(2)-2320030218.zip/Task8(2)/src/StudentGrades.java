import java.util.*;

class StudentGrades {
    private Map<Integer, Set<Integer>> studentGrades;

    public StudentGrades() {
        studentGrades = new HashMap<>();
    }

    // Method to add a grade for a student
    public void addGrade(int studentID, int grade) {
        studentGrades.putIfAbsent(studentID, new HashSet<>());
        studentGrades.get(studentID).add(grade);
        System.out.println("Grade " + grade + " added for Student ID: " + studentID);
    }

    // Method to retrieve grades for a student
    public Set<Integer> getGrades(int studentID) {
        return studentGrades.getOrDefault(studentID, Collections.emptySet());
    }

    // Method to display all students and their grades
    public void displayAllGrades() {
        if (studentGrades.isEmpty()) {
            System.out.println("No student grades recorded.");
        } else {
            System.out.println("Student Grades:");
            for (Map.Entry<Integer, Set<Integer>> entry : studentGrades.entrySet()) {
                System.out.println("Student ID " + entry.getKey() + " -> Grades: " + entry.getValue());
            }
        }
    }

    public static void main(String[] args) {
        StudentGrades sg = new StudentGrades();
        
        // Adding student grades
        sg.addGrade(101, 85);
        sg.addGrade(101, 90);
        sg.addGrade(102, 78);
        sg.addGrade(103, 92);
        sg.addGrade(101, 85); // Duplicate grade will not be added (Set property)
        
        // Retrieving grades for a specific student
        System.out.println("Grades for Student ID 101: " + sg.getGrades(101));
        
        // Displaying all student grades
        sg.displayAllGrades();
    }
}
