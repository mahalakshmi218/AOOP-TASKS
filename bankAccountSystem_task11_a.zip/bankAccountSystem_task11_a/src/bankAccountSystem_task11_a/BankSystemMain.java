package bankAccountSystem_task11_a;

public class BankSystemMain {
    public static void main(String[] args) {
        BankAccount sharedAccount = new BankAccount(1000); // Initial balance

        Thread user1 = new Thread(new User(sharedAccount, true, 500), "User1");
        Thread user2 = new Thread(new User(sharedAccount, false, 300), "User2");
        Thread user3 = new Thread(new User(sharedAccount, true, 700), "User3");
        Thread user4 = new Thread(new User(sharedAccount, false, 1500), "User4"); // Insufficient funds
        Thread user5 = new Thread(new User(sharedAccount, false, 200), "User5");

        user1.start();
        user2.start();
        user3.start();
        user4.start();
        user5.start();
    }
}
