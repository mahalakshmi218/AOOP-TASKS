package bankAccountSystem_task11_a;

public class User implements Runnable {
    private BankAccount account;
    private boolean depositOperation;
    private double amount;

    public User(BankAccount account, boolean depositOperation, double amount) {
        this.account = account;
        this.depositOperation = depositOperation;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (depositOperation) {
            account.deposit(amount);
        } else {
            account.withdraw(amount);
        }
    }
}