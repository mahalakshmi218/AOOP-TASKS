import java.util.HashMap;
import java.util.Map;

class ContactManager {
    private Map<String, String> contacts;

    public ContactManager() {
        this.contacts = new HashMap<>();
    }

    // Method to add a contact
    public void addContact(String name, String phoneNumber) {
        contacts.put(name, phoneNumber);
        System.out.println("Contact added: " + name + " -> " + phoneNumber);
    }

    // Method to remove a contact
    public void removeContact(String name) {
        if (contacts.containsKey(name)) {
            contacts.remove(name);
            System.out.println("Contact removed: " + name);
        } else {
            System.out.println("Contact not found: " + name);
        }
    }

    // Method to retrieve a contact's phone number
    public String getPhoneNumber(String name) {
        return contacts.getOrDefault(name, "Contact not found");
    }

    // Method to list all contacts
    public void listAllContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.println("Contact List:");
            for (Map.Entry<String, String> entry : contacts.entrySet()) {
                System.out.println(entry.getKey() + " -> " + entry.getValue());
            }
        }
    }
}

public class ContactManagerDemo {
    public static void main(String[] args) {
        ContactManager cm = new ContactManager();

        // Adding contacts
        cm.addContact("Alice", "123-456-7890");
        cm.addContact("Bob", "987-654-3210");
        cm.addContact("Charlie", "555-666-7777");

        // Retrieving a contact's phone number
        System.out.println("Bob's Phone Number: " + cm.getPhoneNumber("Bob"));

        // Removing a contact
        cm.removeContact("Alice");

        // Listing all contacts
        cm.listAllContacts();
    }
}
