package bank;

public class Main {
    public static void main(String[] args) {
        Account account = new Account(1001, 1000); // Initial balance = 1000

        // Creating Runnable-based threads
        Thread t1 = new Thread(new TransactionRunnable(account, 500, true), "Thread-1");
        Thread t2 = new Thread(new TransactionRunnable(account, 300, false), "Thread-2");

        // Creating Thread-based threads
        TransactionThread t3 = new TransactionThread(account, 700, true);
        t3.setName("Thread-3");
        TransactionThread t4 = new TransactionThread(account, 1200, false);
        t4.setName("Thread-4");

        // Starting all threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();

        // Ensuring all threads complete before printing the final balance
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final Account Balance: " + account.getBalance());
    }
}
