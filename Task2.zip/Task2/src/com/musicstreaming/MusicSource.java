package com.musicstreaming;

public interface MusicSource {
	void play();
}
