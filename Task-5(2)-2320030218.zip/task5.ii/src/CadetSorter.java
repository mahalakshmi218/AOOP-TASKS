import java.util.Collections;
import java.util.List;

class CadetSorter {
    public static void sortCadets(List<Cadet> cadets) {
        Collections.sort(cadets);
    }
}
