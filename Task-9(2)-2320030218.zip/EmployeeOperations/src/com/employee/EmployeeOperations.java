package com.employee;

import java.util.*;
import java.util.stream.Collectors;

class Employee {
    String name;
    int age;
    String department;
    double salary;

    public Employee(String name, int age, String department, double salary) {
        this.name = name;
        this.age = age;
        this.department = department;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return name + " (Age: " + age + ", Department: " + department + ", Salary: " + salary + ")";
    }
}

public class EmployeeOperations {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("Alice", 30, "IT", 70000),
            new Employee("Bob", 28, "HR", 50000),
            new Employee("Charlie", 35, "IT", 90000),
            new Employee("David", 40, "Finance", 85000),
            new Employee("Eve", 25, "HR", 48000)
        );

        // 1. Filtering employees by Department (IT Department)
        System.out.println("Employees in IT Department:");
        employees.stream()
                .filter(emp -> "IT".equals(emp.department))
                .forEach(System.out::println);

        // 2. Sorting employees by their names
        System.out.println("\nEmployees sorted by name:");
        employees.stream()
                .sorted(Comparator.comparing(emp -> emp.name))
                .forEach(System.out::println);

        // 3. Find the employee with the highest salary
        Optional<Employee> highestPaid = employees.stream()
                .max(Comparator.comparingDouble(emp -> emp.salary));
        highestPaid.ifPresent(emp -> System.out.println("\nEmployee with highest salary: " + emp));

        // 4. Calculate the average salary of employees
        double averageSalary = employees.stream()
                .collect(Collectors.averagingDouble(emp -> emp.salary));
        System.out.println("\nAverage Salary: " + averageSalary);
    }
}