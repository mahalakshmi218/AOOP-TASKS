package com.shop;

import java.util.*;
import java.util.function.Predicate;

class Employee {
    String name;
    int age;
    int experience;

    public Employee(String name, int age, int experience) {
        this.name = name;
        this.age = age;
        this.experience = experience;
    }

    @Override
    public String toString() {
        return name + " (Age: " + age + ", Experience: " + experience + " years)";
    }
}

public class CoffeeShop {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Employee1", 30, 5));
        employees.add(new Employee("Employee2", 28, 4));
        employees.add(new Employee("Employee3", 26, 3));
        employees.add(new Employee("Employee4", 24, 1));
        employees.add(new Employee("Employee5", 22, 0));

        // Sorting employees based on experience (Descending order)
        employees.sort(Comparator.comparingInt(emp -> -emp.experience));

        System.out.println("Employees standing in queue based on experience:");
        employees.forEach(System.out::println);

        // Predicate to filter employees with more than 2 years of experience
        Predicate<Employee> bonusEligibility = emp -> emp.experience > 2;
        
        System.out.println("\nEmployees eligible for bonus:");
        employees.stream()
                .filter(bonusEligibility)
                .forEach(emp -> System.out.println(emp.name + " receives a bonus."));
    }
}