/**
 * 
 */
/**
 * 
 */
module CoffeeShop {
}